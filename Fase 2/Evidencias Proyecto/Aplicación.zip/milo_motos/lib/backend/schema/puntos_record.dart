import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PuntosRecord extends FirestoreRecord {
  PuntosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "foto" field.
  String? _foto;
  String get foto => _foto ?? '';
  bool hasFoto() => _foto != null;

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "descripcion" field.
  String? _descripcion;
  String get descripcion => _descripcion ?? '';
  bool hasDescripcion() => _descripcion != null;

  // "ubicacion" field.
  String? _ubicacion;
  String get ubicacion => _ubicacion ?? '';
  bool hasUbicacion() => _ubicacion != null;

  // "coords" field.
  LatLng? _coords;
  LatLng? get coords => _coords;
  bool hasCoords() => _coords != null;

  void _initializeFields() {
    _foto = snapshotData['foto'] as String?;
    _nombre = snapshotData['nombre'] as String?;
    _descripcion = snapshotData['descripcion'] as String?;
    _ubicacion = snapshotData['ubicacion'] as String?;
    _coords = snapshotData['coords'] as LatLng?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('puntos');

  static Stream<PuntosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PuntosRecord.fromSnapshot(s));

  static Future<PuntosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PuntosRecord.fromSnapshot(s));

  static PuntosRecord fromSnapshot(DocumentSnapshot snapshot) => PuntosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PuntosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PuntosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PuntosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PuntosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPuntosRecordData({
  String? foto,
  String? nombre,
  String? descripcion,
  String? ubicacion,
  LatLng? coords,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'foto': foto,
      'nombre': nombre,
      'descripcion': descripcion,
      'ubicacion': ubicacion,
      'coords': coords,
    }.withoutNulls,
  );

  return firestoreData;
}

class PuntosRecordDocumentEquality implements Equality<PuntosRecord> {
  const PuntosRecordDocumentEquality();

  @override
  bool equals(PuntosRecord? e1, PuntosRecord? e2) {
    return e1?.foto == e2?.foto &&
        e1?.nombre == e2?.nombre &&
        e1?.descripcion == e2?.descripcion &&
        e1?.ubicacion == e2?.ubicacion &&
        e1?.coords == e2?.coords;
  }

  @override
  int hash(PuntosRecord? e) => const ListEquality()
      .hash([e?.foto, e?.nombre, e?.descripcion, e?.ubicacion, e?.coords]);

  @override
  bool isValidKey(Object? o) => o is PuntosRecord;
}
