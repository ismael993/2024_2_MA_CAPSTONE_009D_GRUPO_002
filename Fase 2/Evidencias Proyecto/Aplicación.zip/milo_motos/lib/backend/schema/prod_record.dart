import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProdRecord extends FirestoreRecord {
  ProdRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "precio" field.
  String? _precio;
  String get precio => _precio ?? '';
  bool hasPrecio() => _precio != null;

  // "imagen" field.
  String? _imagen;
  String get imagen => _imagen ?? '';
  bool hasImagen() => _imagen != null;

  // "descripcion" field.
  String? _descripcion;
  String get descripcion => _descripcion ?? '';
  bool hasDescripcion() => _descripcion != null;

  // "numero_user" field.
  String? _numeroUser;
  String get numeroUser => _numeroUser ?? '';
  bool hasNumeroUser() => _numeroUser != null;

  // "categoria" field.
  String? _categoria;
  String get categoria => _categoria ?? '';
  bool hasCategoria() => _categoria != null;

  void _initializeFields() {
    _nombre = snapshotData['nombre'] as String?;
    _precio = snapshotData['precio'] as String?;
    _imagen = snapshotData['imagen'] as String?;
    _descripcion = snapshotData['descripcion'] as String?;
    _numeroUser = snapshotData['numero_user'] as String?;
    _categoria = snapshotData['categoria'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Prod');

  static Stream<ProdRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProdRecord.fromSnapshot(s));

  static Future<ProdRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProdRecord.fromSnapshot(s));

  static ProdRecord fromSnapshot(DocumentSnapshot snapshot) => ProdRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProdRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProdRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProdRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProdRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProdRecordData({
  String? nombre,
  String? precio,
  String? imagen,
  String? descripcion,
  String? numeroUser,
  String? categoria,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nombre': nombre,
      'precio': precio,
      'imagen': imagen,
      'descripcion': descripcion,
      'numero_user': numeroUser,
      'categoria': categoria,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProdRecordDocumentEquality implements Equality<ProdRecord> {
  const ProdRecordDocumentEquality();

  @override
  bool equals(ProdRecord? e1, ProdRecord? e2) {
    return e1?.nombre == e2?.nombre &&
        e1?.precio == e2?.precio &&
        e1?.imagen == e2?.imagen &&
        e1?.descripcion == e2?.descripcion &&
        e1?.numeroUser == e2?.numeroUser &&
        e1?.categoria == e2?.categoria;
  }

  @override
  int hash(ProdRecord? e) => const ListEquality().hash([
        e?.nombre,
        e?.precio,
        e?.imagen,
        e?.descripcion,
        e?.numeroUser,
        e?.categoria
      ]);

  @override
  bool isValidKey(Object? o) => o is ProdRecord;
}
