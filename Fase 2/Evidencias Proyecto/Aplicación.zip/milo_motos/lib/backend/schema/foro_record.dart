import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ForoRecord extends FirestoreRecord {
  ForoRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userID" field.
  String? _userID;
  String get userID => _userID ?? '';
  bool hasUserID() => _userID != null;

  // "mensaje" field.
  String? _mensaje;
  String get mensaje => _mensaje ?? '';
  bool hasMensaje() => _mensaje != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "username" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as String?;
    _mensaje = snapshotData['mensaje'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _username = snapshotData['username'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('foro');

  static Stream<ForoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ForoRecord.fromSnapshot(s));

  static Future<ForoRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ForoRecord.fromSnapshot(s));

  static ForoRecord fromSnapshot(DocumentSnapshot snapshot) => ForoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ForoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ForoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ForoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ForoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createForoRecordData({
  String? userID,
  String? mensaje,
  DateTime? timestamp,
  String? username,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'mensaje': mensaje,
      'timestamp': timestamp,
      'username': username,
    }.withoutNulls,
  );

  return firestoreData;
}

class ForoRecordDocumentEquality implements Equality<ForoRecord> {
  const ForoRecordDocumentEquality();

  @override
  bool equals(ForoRecord? e1, ForoRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.mensaje == e2?.mensaje &&
        e1?.timestamp == e2?.timestamp &&
        e1?.username == e2?.username;
  }

  @override
  int hash(ForoRecord? e) => const ListEquality()
      .hash([e?.userID, e?.mensaje, e?.timestamp, e?.username]);

  @override
  bool isValidKey(Object? o) => o is ForoRecord;
}
