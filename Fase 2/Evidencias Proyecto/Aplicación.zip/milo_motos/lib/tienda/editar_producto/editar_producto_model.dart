import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'editar_producto_widget.dart' show EditarProductoWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditarProductoModel extends FlutterFlowModel<EditarProductoWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for tituloAgregar widget.
  FocusNode? tituloAgregarFocusNode;
  TextEditingController? tituloAgregarTextController;
  String? Function(BuildContext, String?)? tituloAgregarTextControllerValidator;
  // State field(s) for descripcionAgregar widget.
  FocusNode? descripcionAgregarFocusNode;
  TextEditingController? descripcionAgregarTextController;
  String? Function(BuildContext, String?)?
      descripcionAgregarTextControllerValidator;
  // State field(s) for numero widget.
  FocusNode? numeroFocusNode;
  TextEditingController? numeroTextController;
  String? Function(BuildContext, String?)? numeroTextControllerValidator;
  // State field(s) for Precio widget.
  FocusNode? precioFocusNode;
  TextEditingController? precioTextController;
  String? Function(BuildContext, String?)? precioTextControllerValidator;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    tituloAgregarFocusNode?.dispose();
    tituloAgregarTextController?.dispose();

    descripcionAgregarFocusNode?.dispose();
    descripcionAgregarTextController?.dispose();

    numeroFocusNode?.dispose();
    numeroTextController?.dispose();

    precioFocusNode?.dispose();
    precioTextController?.dispose();
  }
}
