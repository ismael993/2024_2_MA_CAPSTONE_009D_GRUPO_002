// Export pages
export '/main/auth1/auth1_widget.dart' show Auth1Widget;
export '/main/recupera_contra/recupera_contra_widget.dart'
    show RecuperaContraWidget;
export '/perfil/editar_perfil/editar_perfil_widget.dart'
    show EditarPerfilWidget;
export '/mapa/mapa_select/mapa_select_widget.dart' show MapaSelectWidget;
export '/mapa_arreglo/mapa_multi_puntos/mapa_multi_puntos_widget.dart'
    show MapaMultiPuntosWidget;
export '/mapa_arreglo/agregar_event_hub/agregar_event_hub_widget.dart'
    show AgregarEventHubWidget;
export '/mapa_arreglo/mapita/mapita_widget.dart' show MapitaWidget;
export '/mapa_arreglo/detalles_puntos/detalles_puntos_widget.dart'
    show DetallesPuntosWidget;
export '/intento_foro/foro/foro_widget.dart' show ForoWidget;
export '/tienda/tienda_1/tienda1_widget.dart' show Tienda1Widget;
export '/tienda/detalles_producto/detalles_producto_widget.dart'
    show DetallesProductoWidget;
export '/tienda_carrito/product/product_widget.dart' show ProductWidget;
export '/main/home_nueva/home_nueva_widget.dart' show HomeNuevaWidget;
export '/tienda/categorias/categorias_widget.dart' show CategoriasWidget;
export '/tienda/mis_productos/mis_productos_widget.dart'
    show MisProductosWidget;
export '/perfil/profile15/profile15_widget.dart' show Profile15Widget;
