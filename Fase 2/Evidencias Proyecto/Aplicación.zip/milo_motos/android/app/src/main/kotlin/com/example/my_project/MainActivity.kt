package com.mycompany.capstone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
