import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _puntoPartida = '';
  String get puntoPartida => _puntoPartida;
  set puntoPartida(String value) {
    _puntoPartida = value;
  }

  String _destino = '';
  String get destino => _destino;
  set destino(String value) {
    _destino = value;
  }

  double _partidaLat = 0.0;
  double get partidaLat => _partidaLat;
  set partidaLat(double value) {
    _partidaLat = value;
  }

  double _partidaLng = 0.0;
  double get partidaLng => _partidaLng;
  set partidaLng(double value) {
    _partidaLng = value;
  }

  double _destinoLat = 0.0;
  double get destinoLat => _destinoLat;
  set destinoLat(double value) {
    _destinoLat = value;
  }

  String _destinoLng = '';
  String get destinoLng => _destinoLng;
  set destinoLng(String value) {
    _destinoLng = value;
  }
}
