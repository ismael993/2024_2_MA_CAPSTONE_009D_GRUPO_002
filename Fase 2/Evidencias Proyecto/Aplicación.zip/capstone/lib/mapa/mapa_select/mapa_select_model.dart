import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'mapa_select_widget.dart' show MapaSelectWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MapaSelectModel extends FlutterFlowModel<MapaSelectWidget> {
  ///  Local state fields for this page.

  String? partida;

  String? destino;

  ///  State fields for stateful widgets in this page.

  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // State field(s) for puntoPartida widget.
  FocusNode? puntoPartidaFocusNode;
  TextEditingController? puntoPartidaTextController;
  String? Function(BuildContext, String?)? puntoPartidaTextControllerValidator;
  // State field(s) for Destino widget.
  FocusNode? destinoFocusNode;
  TextEditingController? destinoTextController;
  String? Function(BuildContext, String?)? destinoTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    puntoPartidaFocusNode?.dispose();
    puntoPartidaTextController?.dispose();

    destinoFocusNode?.dispose();
    destinoTextController?.dispose();
  }
}
