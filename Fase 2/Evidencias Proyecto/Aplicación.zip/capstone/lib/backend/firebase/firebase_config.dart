import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCdn-YJ1LShngR-ef_DZ-cQotM9XeOLOcU",
            authDomain: "capstone-0rlr24.firebaseapp.com",
            projectId: "capstone-0rlr24",
            storageBucket: "capstone-0rlr24.firebasestorage.app",
            messagingSenderId: "485391574018",
            appId: "1:485391574018:web:51c65906110333a3d6f31b"));
  } else {
    await Firebase.initializeApp();
  }
}
