import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const String Partida =
      'Islas+Madeiras+1598,+9090848+Santiago,+Cerro+Navia,+Región+Metropolitana';
  static const String Destino =
      'Duoc+UC:+sede+Maipu+-+Av.+Esq.+Blanca+501,+9251863+Maipú,+Región+Metropolitana';
  static const String PLat = '-33.419762904523104';
  static const String PLng = '-70.7464245017191';
  static const String DLat = '-33.51103563656487';
  static const String DLng = '-70.75255657585754';
}
