// Export pages
export '/main/auth1/auth1_widget.dart' show Auth1Widget;
export '/main/recupera_contra/recupera_contra_widget.dart'
    show RecuperaContraWidget;
export '/main/home/home_widget.dart' show HomeWidget;
export '/perfil/perfil/perfil_widget.dart' show PerfilWidget;
export '/perfil/editar_perfil/editar_perfil_widget.dart'
    show EditarPerfilWidget;
export '/mapa/mapa_select/mapa_select_widget.dart' show MapaSelectWidget;
export '/mapa_arreglo/mapa_multi_puntos/mapa_multi_puntos_widget.dart'
    show MapaMultiPuntosWidget;
export '/mapa_arreglo/agregar_event_hub/agregar_event_hub_widget.dart'
    show AgregarEventHubWidget;
export '/mapa_arreglo/mapita/mapita_widget.dart' show MapitaWidget;
export '/mapa_arreglo/detalles_puntos/detalles_puntos_widget.dart'
    show DetallesPuntosWidget;
export '/intento_foro/foro/foro_widget.dart' show ForoWidget;
export '/tienda/tienda_1/tienda1_widget.dart' show Tienda1Widget;
export '/tienda/detalles_producto/detalles_producto_widget.dart'
    show DetallesProductoWidget;
